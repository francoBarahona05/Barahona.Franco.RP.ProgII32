/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *▪ int id: identificador único del evento.
▪ String nombre: nombre del evento.
▪ LocalDate fecha: fecha del evento.
▪ Constructor para inicializar los atributos.
▪ Métodos getter y un método toString para representar los datos del evento.
 */
import java.time.LocalDate;

public abstract class Evento implements Serializable{
    protected int id;
    protected String nombre;
    protected LocalDate fecha;

    public Evento(int id, String nombre, LocalDate fecha) { 
        this.id = id;
        this.nombre = nombre;
        this.fecha = fecha;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Evento{" + "id=" + id + ", nombre=" + nombre + ", fecha=" + fecha + '}';
    }

    public LocalDate getFecha() {
        return fecha;
    }

}
