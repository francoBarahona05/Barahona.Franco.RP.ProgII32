
package service;

import java.nio.file.Path;


import java.nio.file.Paths;

public class AppConfig {

    // Definir las rutas de los archivos de configuración
    public static final Path PATH_SER = Paths.get("src/data/eventos.bin");  // Ruta del archivo binario
    public static final Path PATH_CSV = Paths.get("src/data/eventos.csv");  // Ruta del archivo CSV

}