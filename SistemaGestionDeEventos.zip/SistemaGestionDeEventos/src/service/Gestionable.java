/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import java.util.List;

public interface Gestionable<T> {
    
    void agregar(T elemento);
    void eliminar(int id);
    List<T> obtenerTodos();
    void limpiar();
    void ordenar();
    void ordenar(java.util.Comparator<T> comparador);
    List<T> filtrar(java.util.function.Predicate<T> criterio);
}