
package model;
import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import service.Gestionable;
import service.SerializableCSV;
public class GestorEventos<T extends SerializableCSV & Comparable<T> & Serializable> implements Gestionable<T> ,Serializable{
    private List<T> lista = new ArrayList<>();

    @Override
     public void agregar(T item){
        if(item == null){
            throw new IllegalArgumentException("parametro no valido");
        }
        lista.add(item);
    };
    @Override
    public void eliminar(int indice) {
        if(indice < 0 || indice >= lista.size()){
            throw new IllegalArgumentException("indice no valido");
        }   
        lista.remove(indice);
    }

    @Override
    public List<T> obtenerTodos() {
        return new ArrayList<>(lista);
    }

    @Override
    public void limpiar() {
        lista.clear();
    }

    private void checkLista(){
        if(lista.isEmpty()){
            throw new IllegalStateException("la lista esta vacia");
        }
    }
    public void ordenar(Comparator<T> comparator){ 
        checkLista();
        if(comparator == null){
            throw new IllegalArgumentException("la comparacion es null");
        }
        lista.sort(comparator);
    }
    public void ordenar(){
        checkLista();
        lista.sort((Comparator<T>)Comparator.naturalOrder());
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado){
        
        List<T> newList = new ArrayList<>();
        for(T item : lista){
            if(predicado.test(item)){
                newList.add(item);
            }
        }
        return newList;
    }
    public void guardarEnBinario(String path) throws IOException {
        if (lista.isEmpty()) {
            throw new IllegalStateException("No se puede guardar un archivo vacío.");
    }
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(lista); 
        }
    }

    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException{
        lista.clear();
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            lista = (List<T>) entrada.readObject();
        }
    }
    

   public void guardarEnCSV(String path) throws IOException{
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(path))){
            bw.write("id,capacidadTripulacion,nombre,categoria\n");
            for(T item : lista){
                bw.write(item.toCSV());
                bw.newLine();
            }
        }
        
       
    }
    public void cargarDesdeCSV(String path, Function<String,T>funcion)throws IOException{   
        lista.clear();
        try(BufferedReader bf = new BufferedReader(new FileReader(path))){
            bf.readLine();
            String linea;
            while ((linea = bf.readLine()) != null) {
                try {
                    lista.add(funcion.apply(linea));
                } catch (Exception e) {
                    System.err.println("Línea mal formada, se omitirá: " + linea);
                }
            }
        }
    }

     public void mostrarTodos(Consumer<T> accion){
        lista.forEach(accion);
    }

}
