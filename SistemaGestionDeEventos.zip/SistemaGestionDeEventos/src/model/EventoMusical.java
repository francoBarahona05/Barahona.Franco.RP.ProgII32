/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.time.LocalDate;
import service.Evento;
import service.GeneroMusical;
import service.SerializableCSV;

/**
 *
 * @author EQUIPO
 */
public class EventoMusical extends Evento implements Comparable<EventoMusical>, SerializableCSV,Serializable {

    private String artista;
    private GeneroMusical generoMusical;

    public GeneroMusical getGeneroMusical() {
        return generoMusical;
    }

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical generoMusical) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.generoMusical = generoMusical;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    @Override
    public int compareTo(EventoMusical evento) {
        return fecha.compareTo(evento.getFecha());
    }

    public static EventoMusical fromCSV(String eventoCSV) {

        String[] valores = eventoCSV.split(",");
        if (valores.length != 5) {
            throw new IllegalArgumentException("Formato CSV inválido.");
        }

        return new EventoMusical(Integer.parseInt(valores[0]), valores[1], LocalDate.parse(valores[2]), valores[3], GeneroMusical.valueOf(valores[4]));
    }

    @Override
    public String toString() {
        return "EventoMusical{" + "artista=" + artista + ", generoMusical=" + generoMusical
                + "id=" + id + ", nombre=" + nombre + ", fecha=" + fecha + '}';
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + fecha + "," + artista + "," + generoMusical;
    }

}
